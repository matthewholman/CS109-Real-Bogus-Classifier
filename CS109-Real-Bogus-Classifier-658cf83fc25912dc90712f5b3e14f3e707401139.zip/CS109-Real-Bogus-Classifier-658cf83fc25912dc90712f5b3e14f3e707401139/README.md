# CS109-Real-Bogus-Classifier
This repository contains the code for a final project in Harvard's CS109 course.

Title: A Real-Bogus Detection Classifier for Pan-STARRS-1 Astronomical Data

Team: The Real-Bogus Classifiers

Matthew Holman mholman@cfa.harvard.edu

Chris Apgar apgar@g.harvard.edu

Freddy Vallenilla fvallenilladorta@g.harvard.edu

Evan Zimmerman zimmerman@college.harvard.edu
